export interface Mensaje {
    success:boolean
    response: string;
    message:string
    dataId: number;
    //data: string;
}
