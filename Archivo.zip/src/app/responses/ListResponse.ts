export interface ListResponse<T> {
    response: string;
    data: T;
  }
