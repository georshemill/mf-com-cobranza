export class SearchCorrespondencia{
	idEmpresa!:number
	idSector!:number
	idManzana!:string
	nroLote!:string
	nroSubLote!:string
	idCalle!:number
	direccion2!:string
	nroCalle!:string
	/*idCiclo!:number
	ciclo!:string
	idSede!:number
	sede!:string
	sucursal!:string
	sector!:string

	manzana!:string
	
	idRutaLectura!:number
	ordenRutaLectura!:number
	idRutaReparto!:number
	ordenRutaReparto!:number
	codigoCatastral!:string
	idTipoServicio!:number
	tipoServicio!:string
	nroSuministro!:number
	nroMedidor!:number
	nroDocIdentidad!:string
	propietario!:string
	encargado!:string
	idTipoEstadoServicio!:number
	estadoServicio!:string
	
	idTarifa!:number
	tarifa!:string
	fechaProrroga!:string
	flagTransferido!:boolean
	fechaTransferencia!:string
	idTipoUsuario!:string
	tipoUsuario!:string
	recibo!:string
	codigoAntiguo!:string
	referencia!:string
	urbanizacion!:string
	idDepartamento!:number 
	idProvincia!:string
	idDistrito!:string
	direccion2!:string
	nroCalle!:string
	checkSucursal!:boolean
	departamento!:string
	provincia!:string
	distrito!:string
	unidadComercial!:number
	unidadDomestica!:number
	unidadEstatal!:number
	unidadIndustrial!:number
	unidadSocial!:number*/
	idSucursal: number | null = null;
	nroSuministro: number | null = null;
	propietario: string | null = null;

}
