export class TipoAccesorioNoReglamentario{
	idEmpresa!:number 
	idTipoConexion!:number 
	idTipoAccesorioNoReglamentado!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}