export class TipoIngresoConexion{
	idEmpresa!:number 
    idTipoIngresoConexion!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}