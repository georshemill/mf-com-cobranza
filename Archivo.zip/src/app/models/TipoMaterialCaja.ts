export class TipoMaterialCaja{
	idEmpresa!:number 
	idTipoConexion!:number 
	descripcion_conex !:string
    idTipoCaja!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}