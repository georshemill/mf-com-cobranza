export class TipoDiametros{
	idEmpresa!:number 
	idTipoConexion!:number 
    idDiametro!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}