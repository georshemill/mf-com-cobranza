export class TipoCorrespondencia{
	idEmpresa!:number 
	idTipoCorrespondencia!:number 
	descripcion !:string
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
}
