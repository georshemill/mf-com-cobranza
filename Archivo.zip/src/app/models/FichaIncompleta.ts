export class FichaIncompleta{
	idEmpresa!:number 
	idTipoFicha!:number 
	descripcion!:string
	orden!:number
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean
}
