export interface TipoResponsable{
	idEmpresa:number 
	idTipoResponsable:number 
	descripcion :string
	orden:number 
	usuarioCreacion:string
	fechaRegistro:string
	estado:boolean 
	tipo:string
}