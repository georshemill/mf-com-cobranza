export interface TipoPresion{
	idEmpresa:number
    idTipoPresionAgua:number 
	descripcion :string
	orden:number 
	usuarioCreacion:string
	fechaRegistro:string
	estado:boolean 
	tipo:string
}