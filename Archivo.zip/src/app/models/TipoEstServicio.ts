export class TipoEstServicio{
	idEmpresa!:number 
	idTipoEstServicio!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}