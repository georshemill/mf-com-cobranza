
export class GestionOrdenTrabajo{
	 flagActualizado!:number
	 flagClandestino!:number
	 //nrosuministro!:number
	 idCalle!:number
	 idEmpresa!:string
	 idSector!:number
	 sector!:string
	 idSucursal!:number
	 direccion!:string
	 ejecutado!:string
	 flagpresupuesto!:number
	 flagtransferido!:number
	 nrocalle!:string 
	 nrocatastro!:number
	 nrosolicitud!:number
	 nuevo!:number
	
}
