export class TipoTapa{
	idEmpresa!:number 
	idTipoConexion!:number 
	descripcion_conex !:string
    idTipoTapa!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}