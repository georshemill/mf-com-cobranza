export interface TipoVereda{
	idEmpresa:number 
	idTipoConexion:number 
	descripcion_conex :string
    idTipoVereda:number 
	descripcion :string
	orden:number 
	usuarioCreacion:string
	fechaRegistro:string
	estado:boolean 
	tipo:string
}