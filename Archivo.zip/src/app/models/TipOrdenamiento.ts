export class TipOrdenamiento{
	idEmpresa!:number 
	idTipoOrdenamiento!:number 
	descripcion !:string
	/*orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string*/
}
