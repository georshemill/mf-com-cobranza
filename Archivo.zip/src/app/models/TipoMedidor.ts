export class TipoMedidor{
	idEmpresa!:number 
	idTipoMedidor!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}