export class MarcaMedidor{
	idEmpresa!:number 
	idTipoMarcaMedidor!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}