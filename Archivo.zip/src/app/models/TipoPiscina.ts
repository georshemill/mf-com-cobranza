export class TipoPiscina{
	idEmpresa!:number 
    idTipoPiscina!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}