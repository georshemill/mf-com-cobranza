export class RequierimientoColateral{
	idRequisito!:number 
	descripcion!:string
}
