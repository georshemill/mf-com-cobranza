export class EstadoMedidor{
	idEmpresa!:number 
	idTipoEstMedidor!:number 
	descripcion!:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}