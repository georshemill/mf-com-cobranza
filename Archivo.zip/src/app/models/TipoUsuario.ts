export class TipoUsuario{
	 idEmpresa!:number 
	 idTipoUsuario!:number
	 descripcion!:string
	 orden!:number 
	 usuarioCreacion!:string
	 fechaRegistro!:string
	 estado!:boolean 
	 tipo!:string
}

