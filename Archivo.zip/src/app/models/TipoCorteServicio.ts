export interface TipoCorteServicio{
	idEmpresa:number 
	idTipoConexion:number 
	descripcion_conex :string
    idTipoCorteServicio:number 
	descripcion :string
	orden:number 
	usuarioCreacion:string
	fechaRegistro:string
	estado:boolean 
	tipo:string
}
