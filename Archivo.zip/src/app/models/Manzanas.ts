export class Manzanas{
	idEmpresa!:number 
	idSucursal!:number 
	idSector!:number 
	idManzana!:number
	descripcion!:string
	orden!:number
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean
}
