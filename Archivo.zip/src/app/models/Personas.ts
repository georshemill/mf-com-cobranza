export class Personas{
	idPersona!:string
	idTipoDocIdentidad!:string
	nroDocIdentidad!:string
	dni!:string
	ruc!:string
	nombres!:string
	apellidos!:string
	razonSocial!:string
	domicilioLegal!:string
	//fechaNac!:string
	nombreCompleto!:string
	fechaRegistro!:string
	usuarioCreacion!:string
	estado!:boolean 
}


	