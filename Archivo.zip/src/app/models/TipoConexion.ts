export class TipoConexion{
	idEmpresa!:number 
	idTipoUsoConexion!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}