export class Rutas{
	idEmpresa!:number 
	idSucursal!:number 
	idSector!:number 
	idRuta!:number 
	IdManzana!:number
	NroOrdenIdManzana!:number
	NroLote!:string
	FlagRutaPeligrosa!:number
	descripcion !:string
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}
