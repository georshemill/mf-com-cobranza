export class TipoModeloCajaConex{
	idEmpresa!:number 
	idTipoConexion!:number 
	idTipoModeloCajaConex!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}