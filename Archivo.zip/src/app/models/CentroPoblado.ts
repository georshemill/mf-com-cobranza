export class CentroPoblado{
	idEmpresa!:number 
	idSucursal!:number 
	idCentroPoblado!:number 
	tipoUrba!:number 
	descripcion !:string
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
}