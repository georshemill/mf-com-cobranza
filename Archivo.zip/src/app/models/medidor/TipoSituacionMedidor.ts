export class TipoSituacionMedidor{
	idEmpresa!:number 
	idTipoSituacionMedidor!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}