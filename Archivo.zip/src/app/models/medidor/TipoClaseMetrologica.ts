export class TipoClaseMetrologica{
	idEmpresa!:number 
	idTipoClaseMetrologica!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}