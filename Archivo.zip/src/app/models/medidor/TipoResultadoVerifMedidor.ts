export class TipoResultadoVerifMedidor{
	idEmpresa!:number 
	idTipoResultadoVerificacionMedidor!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}