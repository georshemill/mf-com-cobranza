export class CapacidadMedidor{
	idEmpresa!:number 
	idTipoCapMedidor!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}