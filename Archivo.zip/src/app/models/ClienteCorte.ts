export class ClienteCorte{
	nroSuministro!:number 
	idEstadoServicio!:number 
	deudaTotal!:number 
}
