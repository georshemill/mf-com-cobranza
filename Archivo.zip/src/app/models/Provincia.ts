export class Provincia{
	idDepartamento!:number 
	idProvincia!:string 
	nombre!:string
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean
}