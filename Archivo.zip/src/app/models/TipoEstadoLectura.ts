export class TipoEstadoLectura{
	idEmpresa!:number 
	idTipoEstLectura!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}