export class TipoEstadoCaja{
	idEmpresa!:number 
	idTipoConexion!:number 
	descripcion_conex !:string
    idTipoEstCaja!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}