export interface Localidad{
	/*idEmpresa:number 
	idTipoConexion:number 
	descripcion_conex :string
    idDiametro:number 
	descripcion :string
	orden:number 
	usuarioCreacion:string
	fechaRegistro:string
	estado:boolean 
	tipo:string*/
	idSucursal:number
	idCiclo:number
	descripcion:string
}