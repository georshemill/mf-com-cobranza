export class Oficina{
	idSucursal!:number 
	idOficina!:number 
	//idDistrito!:number
	descripcion!:string
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean
	idSectorOperacional!:number 
	sectorOperacional!:string
}
