export class Distrito{
	idDepartamento!:number 
	idProvincia!:string 
	idDistrito!:string
	nombre!:string
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean
}

