export class Tarifas{
	
	idEmpresa!:number
	idSucursal!:number
	idTipoCategoria!:number
	idTarifa!:number
	nombreTarifa!:string
	volumenAsignado!:string
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
}
