export class TipoConstruccion{
	idEmpresa!:number 
	idTipoConstruccion!:number 
	descripcion!:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}