export class TipoMaterialTubo{
	idEmpresa!:number 
	idTipoConexion!:number 
	descripcion_conex !:string
    idTipoMaterialTubo!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}
