export class Departamento{
	idDepartamento!:number 
	nombre!:string
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean
}