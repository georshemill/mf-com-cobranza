export class Urbanizacion{
	idEmpresa!:number 
	idSucursal!:number 
	idUrbanizacion!:number 
	tipoUrbanizacion!:string 
	descripcion !:string
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
}