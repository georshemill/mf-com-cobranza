export class Sector{
	idSucursal!:number 
	idSector!:number 
	//idDistrito!:number
	nombre!:string
	idSectorOperacional:number | null = null;
	sectorOperacional:string| null = null;
}
