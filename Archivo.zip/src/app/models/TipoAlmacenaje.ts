export class TipoAlmacenaje{
	idEmpresa!:number 
	idTipoAlmacenaje!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}