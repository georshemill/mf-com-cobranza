export class TipoFacturacion{
	idEmpresa!:number 
	idTipoFacturacion!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}
