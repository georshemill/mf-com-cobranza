export class TipoActividad{
	 idEmpresa!:number 
	 idTipoActividad!:number
	 descripcion!:string
	 descripcionCorta!:string
	 orden!:number 
	 usuarioCreacion!:string
	 fechaRegistro!:string
	 estado!:boolean 
	 tipo!:string
}
