export class TipoAccesorios{
	idEmpresa!:number 
	idTipoConexion!:number 
	idTipoAccesorioConex!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}
