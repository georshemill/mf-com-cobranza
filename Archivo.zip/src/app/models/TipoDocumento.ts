export class TipoDocumento{
	 idTipoDocIdentidad!:string 
	 descripcionLarga!:string
	 descripcionCorta!:string
	 longitud!:number 
	 tipoDato!:number 
	 tipoContribuyente!:number 
	 longitudExacta!:number 
	 flagRazonSocial!:number 
	 flagExtranjero!:number 
	 usuarioCreacion!:string
	 fechaRegistro!:string
	 estado!:boolean 
	 tipo!:string
}

	