export class TipoPredio{
	idEmpresa!:number 
	idTipoPredio!:number 
	descripcion!:string
	orden!:number
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean
}
