export class Ciclo{
	idSucursal:number | null = null;
	idCiclo:number | null = null;
	descripcion!:string
	sucursal:string | null = null;
	idSectorOperacional!:number 
	sectorOperacional!:string
}
