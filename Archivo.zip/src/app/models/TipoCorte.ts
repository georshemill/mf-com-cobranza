export class TipoCorte{
	idTipoCore!:number 
	flagCore!:number 
	descripcion !:string
}
