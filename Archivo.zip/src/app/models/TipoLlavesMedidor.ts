export class TipoLlavesMedidor{
	idEmpresa!:number 
	idTipollaveMedidor!:number 
	descripcion !:string
	orden!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}