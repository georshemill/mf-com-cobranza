export class TipoServicio{
	 idEmpresa!:number 
	 idTipoServicio!:number
	 descripcion!:string
	 descripcionCorta!:string
	 orden!:number 
	 usuarioCreacion!:string
	 fechaRegistro!:string
	 estado!:boolean 
	 tipo!:string
}
