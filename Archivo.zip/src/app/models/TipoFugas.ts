export interface TipoFugas{
	idEmpresa:number 
	idTipoConexion:number 
	descripcion_conex :string
    idTipoFuga:number 
	descripcion :string
	orden:number 
	usuarioCreacion:string
	fechaRegistro:string
	estado:boolean 
	tipo:string
}