export class Inspector{
	idInspector!:number 
	dni!:string 
	nombres !:string

}
