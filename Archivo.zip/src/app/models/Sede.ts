export class Sede{
	idEmpresa!:number 
	idSede!:number 
	nombre!:string
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean
	idSectorOperacional!:number 
	sectorOperacional!:string
}
