export class Calles{
	idEmpresa!:number 
	idSucursal!:number 
	idCalle!:number 
	tipocalle!:string 
	idCalleReferencia!:number 
	idSucReferencia!:number 
	usuarioCreacion!:string
	fechaRegistro!:string
	estado!:boolean 
	tipo!:string
}


