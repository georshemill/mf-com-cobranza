export const environment = {
    production: false,
    HOST_API:"http://localhost:8053/", 
    //HOST_API:"https://gateway1.emapasalas.net.pe/", 
}